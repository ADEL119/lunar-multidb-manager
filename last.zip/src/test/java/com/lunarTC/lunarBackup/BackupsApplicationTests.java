package com.lunarTC.lunarBackup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackupsApplicationTests {

	@Test
	void contextLoads() {
	}

}
